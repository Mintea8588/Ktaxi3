package com.example.taximeter;

import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.graphics.Color; import android.os.*; import android.webkit.*; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 TextView fare, dist, speed, gps, gap; Button start, stop, settings; WebView map; long lastMapLoad=0; double lastLat=Double.NaN,lastLng=Double.NaN;
 @Override public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,20,22,12);root.setBackgroundColor(Color.WHITE);
  LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL); TextView title=t("Korea Taxi Meter",24);top.addView(title,new LinearLayout.LayoutParams(0,55,1));settings=new Button(this);settings.setText("⚙ 요금 설정");top.addView(settings);root.addView(top);
  fare=t("0원",42);fare.setGravity(Gravity.CENTER);root.addView(fare,new LinearLayout.LayoutParams(-1,75));
  dist=t("주행거리 0.00 km",19);speed=t("속도 0 km/h",18);gps=t("GPS 대기",16);gap=t("GPS 보정거리 0.00 km",16);root.addView(dist);root.addView(speed);root.addView(gps);root.addView(gap);
  LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);start=new Button(this);start.setText("운행 시작");stop=new Button(this);stop.setText("운행 종료");buttons.addView(start,new LinearLayout.LayoutParams(0,60,1));buttons.addView(stop,new LinearLayout.LayoutParams(0,60,1));root.addView(buttons);
  TextView mt=t("현위치 · Google 지도",16);mt.setPadding(0,10,0,6);root.addView(mt);
  map=new WebView(this);map.setBackgroundColor(Color.LTGRAY);map.getSettings().setJavaScriptEnabled(true);map.getSettings().setDomStorageEnabled(true);map.getSettings().setGeolocationEnabled(true);map.setWebChromeClient(new WebChromeClient());root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
  setContentView(root);
  if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);
  settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
  start.setOnClickListener(v->{ if(Build.VERSION.SDK_INT>=26) startForegroundService(new Intent(this,MeterService.class)); else startService(new Intent(this,MeterService.class)); });
  stop.setOnClickListener(v->{stopService(new Intent(this,MeterService.class));});
  registerReceiver(new BroadcastReceiver(){public void onReceive(Context c,Intent i){if("METER_UPDATE".equals(i.getAction())){fare.setText(i.getIntExtra("fare",0)+"원");dist.setText(String.format(Locale.KOREA,"주행거리 %.2f km",i.getDoubleExtra("distance",0)));speed.setText(String.format(Locale.KOREA,"속도 %.0f km/h",i.getDoubleExtra("speed",0)));gps.setText(i.getStringExtra("gps"));gap.setText(String.format(Locale.KOREA,"GPS 보정거리 %.2f km",i.getDoubleExtra("gap",0)));updateMap(i.getDoubleExtra("lat",Double.NaN),i.getDoubleExtra("lng",Double.NaN));}}},new IntentFilter("METER_UPDATE"), Context.RECEIVER_NOT_EXPORTED);
  loadMap(37.5665,126.9780);
 }
 void updateMap(double lat,double lng){if(Double.isNaN(lat)||Double.isNaN(lng))return; if(Double.isNaN(lastLat)||Math.abs(lat-lastLat)+Math.abs(lng-lastLng)>0.0004 || System.currentTimeMillis()-lastMapLoad>5000){lastLat=lat;lastLng=lng;loadMap(lat,lng);}}
 void loadMap(double lat,double lng){lastMapLoad=System.currentTimeMillis();String url="https://www.google.com/maps/search/?api=1&query="+lat+","+lng+"&zoom=16";map.loadUrl(url);}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.BLACK);v.setPadding(0,5,0,5);return v;}
 @Override protected void onDestroy(){super.onDestroy();}
}
