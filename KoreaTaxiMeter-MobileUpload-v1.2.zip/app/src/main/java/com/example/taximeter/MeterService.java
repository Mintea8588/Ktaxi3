package com.example.taximeter;

import android.app.*; import android.content.*; import android.location.Location; import android.os.*;
import androidx.annotation.NonNull; import com.google.android.gms.location.*; import java.util.*;

public class MeterService extends Service {
 private FusedLocationProviderClient client; private Location last; private long gapStart=0; private double total=0, gapDistance=0; private float lastSpeed=0; private static final double MIN_GAP=10.0, MAX_GAP_SEC=180.0, MAX_GAP_DISTANCE=5_000.0;
 private long lowSeconds=0, lastTick=0;
 private final LocationCallback cb=new LocationCallback(){@Override public void onLocationResult(@NonNull LocationResult r){for(Location l:r.getLocations()) handle(l);}};
 @Override public void onCreate(){super.onCreate(); client=LocationServices.getFusedLocationProviderClient(this); startForeground(77, notification("택시미터 운행 중")); request();}
 private void request(){LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000).setMinUpdateIntervalMillis(500).setMaxUpdateDelayMillis(2000).build(); try{client.requestLocationUpdates(req,cb,Looper.getMainLooper());}catch(SecurityException e){stopSelf();}}
 private void handle(Location l){
  long now=System.currentTimeMillis();
  if(last==null){last=l;lastTick=now;send(l);return;}
  double dt=(now-lastTick)/1000.0; float acc=l.hasAccuracy()?l.getAccuracy():999;
  if(acc>80){if(gapStart==0)gapStart=lastTick; send(l);return;}
  if(gapStart>0){
   double gapSec=(now-gapStart)/1000.0; float v=Math.max(0,lastSpeed)*1000/3600f; float straight=last.distanceTo(l); double expected=v*gapSec;
   if(gapSec<=MAX_GAP_SEC && straight>=MIN_GAP && straight<=MAX_GAP_DISTANCE){double ratio=expected>1?straight/expected:1; if(expected<1 || (ratio>=0.35&&ratio<=2.8)){total+=straight;gapDistance+=straight;}}
   gapStart=0;
  } else {
   float d=last.distanceTo(l);
   if(d>=MIN_GAP && d<1000 && dt<15){
    double speedKmh=(dt>0?d/dt:0)*3.6;
    if(speedKmh >= new TariffConfig(this).lowSpeedKmh()) total+=d;
   }
  }
  if(l.hasSpeed()) lastSpeed=l.getSpeed(); else if(dt>0) lastSpeed=(float)(last.distanceTo(l)/dt);
  double speedKmh=lastSpeed*3.6;
  if(speedKmh < new TariffConfig(this).lowSpeedKmh() && dt>0 && dt<10) lowSeconds+=Math.round(dt);
  last=l; lastTick=now; send(l);
 }
 private void send(Location l){Intent i=new Intent("METER_UPDATE");i.putExtra("fare",calcFare());i.putExtra("distance",total/1000);i.putExtra("speed",lastSpeed*3.6);i.putExtra("gap",gapDistance/1000);i.putExtra("lat",l.getLatitude());i.putExtra("lng",l.getLongitude());i.putExtra("gps", "GPS 정상 · ±"+(int)(l.hasAccuracy()?l.getAccuracy():0)+" m");sendBroadcast(i);}
 private boolean inNight(){TariffConfig c=new TariffConfig(this); if(!c.autoNight())return false; try{String[] a=c.nightStart().split(":");String[] b=c.nightEnd().split(":");java.util.Calendar now=java.util.Calendar.getInstance(), s=(java.util.Calendar)now.clone(), e=(java.util.Calendar)now.clone();s.set(java.util.Calendar.HOUR_OF_DAY,Integer.parseInt(a[0]));s.set(java.util.Calendar.MINUTE,Integer.parseInt(a[1]));e.set(java.util.Calendar.HOUR_OF_DAY,Integer.parseInt(b[0]));e.set(java.util.Calendar.MINUTE,Integer.parseInt(b[1]));if(e.before(s))e.add(java.util.Calendar.DATE,1);if(now.before(s) && now.get(java.util.Calendar.HOUR_OF_DAY)<12)s.add(java.util.Calendar.DATE,-1);return !now.before(s)&&now.before(e);}catch(Exception ex){return false;}}
 private int calcFare(){TariffConfig c=new TariffConfig(this); int f=c.baseFare(); double beyond=Math.max(0,total-c.baseDistanceM()); f += (int)Math.floor(beyond/c.distanceUnitM())*c.distanceUnitFare(); f += (int)Math.floor(lowSeconds/(double)c.timeUnitSec())*c.timeUnitFare(); if(inNight())f += Math.round(f*c.nightPct()/100f); if(c.outOfArea())f += Math.round(f*c.outPct()/100f); return f;}
 private Notification notification(String s){String ch="meter";NotificationManager nm=getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"Taxi Meter",NotificationManager.IMPORTANCE_LOW));return new Notification.Builder(this,ch).setContentTitle("Korea Taxi Meter").setContentText(s).setSmallIcon(android.R.drawable.ic_menu_mylocation).build();}
 @Override public void onDestroy(){client.removeLocationUpdates(cb);super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
